
from django.urls import path
from .import views
urlpatterns = [
    
    path('home',views.Home_Page.as_view(),name="mainpage"),
    path('createaccount',views.CreateAccount.as_view(),name='CreateAccount'),
    path('login',views.UserLogin.as_view(),name='login'),
    path('logout',views.User_logout.as_view(),name='logout'),
]
