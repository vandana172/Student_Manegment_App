
from django.db import models
from django.contrib.auth.models import User


class StudentClass(models.Model):
    name = models.CharField(max_length=100)
    section = models.CharField(max_length=4)
    def __str__(self):
        return self.name
class UserProfileData(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    phone = models.CharField(max_length=11, blank=True) #  change the field to watever works for you
    dob=models.DateField(null=True,blank=True)
    status=models.BooleanField(default=True)
    image = models.ImageField(upload_to='images',null=True,blank=True)
    class_opted=models.ForeignKey(StudentClass,null=True,blank=True,on_delete=models.CASCADE)
    
    def __str__(self):
        return self.user
        
