
from django.shortcuts import render,redirect,HttpResponseRedirect
from django.views import View
from django.contrib.auth.models import User ,Group
from django.contrib.auth import logout,login,authenticate
from .forms import UserCreateforms,LoginForm,UserProfileForm
from django.contrib import messages
from .models import UserProfileData

# Create your views here.

class Home_Page(View):
    template_name="base.html"
    def get(self,request):
        return render(request,self.template_name)


class CreateAccount(View):
    tamplate_name = "sinup.html"
    def get(self,request):
        fm2 =UserProfileForm()
        fm=UserCreateforms()
        return render(request,self.tamplate_name,{"form":fm,"form1":fm2})
    def post(self,request):
        if request.method=='POST':
            fm2 =UserProfileForm(request.POST,request.FILES)
            fm=UserCreateforms(request.POST)
            print(fm,fm2)
            
            if fm.is_valid(): 
                if fm2.is_valid():
                    messages.success(request, "Congratulations You are registred")
                    user=fm.save()
                    obj = fm2.save(commit=False)
                    print(fm2,user)
            
                obj.user = user
                obj.save()
                # group created
                group = Group.objects.get_or_create(name="Author")
                group = Group.objects.get(name='Author')
                user.groups.add(group)
                fm =UserCreateforms()
                fm2 =UserProfileForm()
        else:
            fm=UserCreateforms()
            fm2 =UserProfileForm()
        return render(request,self.tamplate_name,{'form':fm,"form1":fm2})

class UserLogin(View):
    template_name="login.html"
    def get(self,request):
        fm=LoginForm()
        return render(request, self.template_name,{'form':fm})

    def post(self,request):
        if request.method=='POST':
            fm = LoginForm(request=request,data=request.POST)
            if fm.is_valid():
                uname = fm.cleaned_data['username']
                upass = fm.cleaned_data['password']
                user = authenticate(username=uname,password=upass)
                if user is not None:
                    login(request,user)
                    group = Group.objects.get(name='Author')
                    users = group.user_set.all()
                    print(users,'Login in Successfuly')
                    messages.success(request,'Login in Successfuly')
                    return HttpResponseRedirect('/home/home')

        else:
            fm=LoginForm()
            messages.success(request,'Login not Successfuly')
            
        return render(request, self.template_name,{'form':fm})

# Logout_User
class User_logout(View):
    def get(self,request):
        if request.user.is_authenticated:
            logout(request)
            return HttpResponseRedirect('/logout/login')
        else:
            return HttpResponseRedirect('/logout/login')