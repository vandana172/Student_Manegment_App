from atexit import register
from django.contrib import admin
from django.contrib.auth.models import User
from . models  import StudentClass, UserProfileData
# Register your models here.
admin.site.register(UserProfileData)

admin.site.register(StudentClass)