from django import forms
from django.contrib.auth.forms import UserCreationForm ,UsernameField,AuthenticationForm
from django.contrib.auth.models import User
from . models import UserProfileData
class UserCreateforms(UserCreationForm):
    password1=forms.CharField(label='Password',widget=forms.PasswordInput(attrs={"class":"form-control"}))
    password2 = forms.CharField(label='Conform Password',widget=forms.PasswordInput(attrs={'class':'form-control'}))
    class Meta:
        model=User
        fields=['username','first_name','last_name','email']
        labels={'username':'Username','first_name':'First_Name','lastname':'LastName','email':'Email'}
        widgets = {
        'username':forms.TextInput(attrs={'class':'form-control'}),
        'first_name':forms.TextInput(attrs={'class':'form-control'}),
        'last_name':forms.TextInput(attrs={'class':'form-control'}),
        'email':forms.EmailInput(attrs={'class':'form-control'})
        }

class UserProfileForm(forms.ModelForm):
    class Meta:
        model = UserProfileData
        fields = ['phone','image','dob','class_opted']
        labels={'phone':'Mobail No','image':'Image','dob':'Date Of Birth','class_opted':'Select_Class'}
        widgets ={'phone':forms.TextInput(attrs={'class':'form-control'}),
        # 'status':forms.TextInput(attrs={'class':'form-control'}),
        'image':forms.FileInput(attrs={'class':'form-control'}),
        # 'class_opted':forms.TextInput(attrs={'class':'form-control'}),
        'dob':forms.DateInput(format='%d/%m/%Y',attrs={'class':'form-control'}),
        }

        
        
class LoginForm(AuthenticationForm):
    username = UsernameField(widget = forms.TextInput(attrs={'autofocus':True,'class':'form-control'}))
    password=forms.CharField(label='Password',strip=False,widget=forms.PasswordInput(attrs={'autocomplete':'current-password','class':'form-control'}))

